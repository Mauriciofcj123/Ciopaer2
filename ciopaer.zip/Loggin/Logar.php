<?php
        include_once("Conexao.php");
        include_once("../Inicial/Inicial.php");

        

?>