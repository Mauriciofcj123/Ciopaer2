function Sair(){
    window.location.href="Sair.php";
}