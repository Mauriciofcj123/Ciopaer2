<?php
    header('Location: Inicial/index.php')
?>